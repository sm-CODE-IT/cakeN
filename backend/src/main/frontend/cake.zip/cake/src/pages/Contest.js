const Contest = () => {
    return (
        <div>
            {"케이크 자랑."}
        </div>
    );
};

export default Contest;